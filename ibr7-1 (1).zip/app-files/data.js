var APP_DATA = {
  "scenes": [
    {
      "id": "0-ibr1",
      "name": "ibr1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.06620350814214859,
        "pitch": 0.05450731002403941,
        "fov": 1.229532022645302
      },
      "linkHotspots": [
        {
          "yaw": -0.148299654658393,
          "pitch": 0.10685086963263757,
          "rotation": 0,
          "target": "5-ibr6"
        },
        {
          "yaw": 3.0689915864349917,
          "pitch": 0.32823968331798525,
          "rotation": 0,
          "target": "1-ibr2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-ibr2",
      "name": "ibr2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.4400968929971079,
          "pitch": 0.11847227775412783,
          "rotation": 0,
          "target": "4-ibr5"
        },
        {
          "yaw": -2.923068130009508,
          "pitch": 0.021107482531505184,
          "rotation": 0,
          "target": "2-ibr3"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-ibr3",
      "name": "ibr3",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0,
          "pitch": 0,
          "rotation": 0,
          "target": "3-ibr4"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-ibr4",
      "name": "ibr4",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "4-ibr5",
      "name": "ibr5",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "5-ibr6",
      "name": "ibr6",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.9883836840270597,
          "pitch": 0.08478914892623735,
          "rotation": 0,
          "target": "6-ibr7"
        },
        {
          "yaw": -1.623670319068264,
          "pitch": 0.5732196373149385,
          "rotation": 0,
          "target": "0-ibr1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "6-ibr7",
      "name": "ibr7",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": -0.11165048799885824,
        "pitch": 0.19556624932344846,
        "fov": 1.229532022645302
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "ibr7-1",
  "settings": {
    "mouseViewMode": "qtvr",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
